#########################################################################
# File Name: exec.sh
# Author: ian
# mail: 18896500132@163.com
# Created Time: Wed 10 Jul 2019 06:00:38 PM CST
#########################################################################
#!/bin/bash

php fans.php &
sleep 1
php like.php &
sleep 1
php comment.php &
