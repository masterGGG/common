#!/usr/bin/php
<?php
/* vim=> set expandtab tabstop=4 softtabstop=4 shiftwidth=4=> */
/**
 * @file test.php
 * @author richard <richard@taomee.com>
 * @date 2011-06-10
class feedid
{
	public $mimi;
	public $cmd_id;
	public $app_id;
	public $version;
	public $timestamp;

	public function to_binary()
	{
		$ret = pack('SLCL', $this->cmd_id, $this->mimi, $this->version, $this->timestamp);
		return $ret;
	}
}
 */
error_reporting(E_ALL);

require_once('../function.php');
require_once('./feedid_class.php');
require_once('../netclient_class.php');

$client = new netclient('10.1.1.197', 58810);

if ($client->open_conn(1) === FALSE) {
    do_log('error', 'ERROR=> client->connect');
    return FALSE;
}
$article = array(
    array("mimi"=>1227401110, "icon"=>"spring.jpg", 'name'=>'春天', 'text'=>'播种','pic'=>'a.png', 'role' => 5),
    array("mimi"=>1227401111, "icon"=>"summer.png", 'name'=>'夏天', 'text'=>'避暑','pic'=>'b.png', 'role' => 3),
    array("mimi"=>1227401112, "icon"=>"autumn.gif", 'name'=>'秋天', 'text'=>'收获','pic'=>'c.gif', 'role' => 9),
    array("mimi"=>1227401113, "icon"=>"winter.jpg", 'name'=>'冬天', 'text'=>'吃饺子','pic'=>'d.jpg', 'role' => 4)
);
for ($i = 0; $i != 1; ++$i) {
    $feedid = new feedid();
    $feedid->mimi = 1227401110 + $i;
    $feedid->cmd_id = 8002;
    $feedid->version = 1;
    $feedid->timestamp = time();
    $feedid_binary = $feedid->to_binary();

    $aid = 3217;
    $pic = 'taomee.png';
    $icon = $article[$i + 1]['icon'];
    $nick = $article[$i + 1]['name'];
    $user_len = 1 + strlen($icon) + 1 + strlen($nick) + 1;
    $user_body = pack('c', strlen($icon)).$icon.pack('c', strlen($nick)).$nick.pack('c', $article[$i + 1]['role']);
    $len = 2 + 2 + 4 + 1 + 4 + 4 + $user_len;
    
    $f_arr_1 = pack('S',$len).$feedid_binary.pack('L', 1).$user_body;
    $f_unpack_ret = unpack('Slen/Scmd/Lmid/Cversion/Ltime/Lapp_id/Lulen',$f_arr_1);

    var_dump($f_unpack_ret);
    $rqst_msg = $f_arr_1;
    $resp_msg = FALSE;
   if (($resp_msg = $client->send_rqst($rqst_msg, 5)) === FALSE) {
        do_log('error', 'ERROR=> client->send_rqst');
        return FALSE;
    }
}

if ($client->close_conn() === FALSE) {
    do_log('error', 'ERROR=> cliet->close_conn');
    return FALSE;
}

