#! /usr/bin/php
<?php

require dirname(__FILE__) . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR .  'setup.inc.php';
require dirname(__FILE__) . DIRECTORY_SEPARATOR . 'Mifan' . DIRECTORY_SEPARATOR .  'noteArticle.php';
require dirname(__FILE__) . DIRECTORY_SEPARATOR . 'Mifan' . DIRECTORY_SEPARATOR .  'pushReq.php';
require dirname(__FILE__) . DIRECTORY_SEPARATOR . 'Mifan' . DIRECTORY_SEPARATOR .  'pushReq_feedInfo.php';
require dirname(__FILE__) . DIRECTORY_SEPARATOR . 'Mifan' . DIRECTORY_SEPARATOR .  'noteRecommendAlarm.php';

                
$redis_client = new Redis();
$redis_client->connect('0.0.0.0', 7023);
$redis_client->auth('ta0mee@123');
$recommend_stat = array(
        'readable' => 1,
        'updatable' => 0,
        'likeCount' => 200,
        'likeIndex' => 20,
        'hotCount' => 50,
        'hotIndex' => 5,
);

$rv = $redis_client->hMset('feeds:recommend:38743982:stat', $recommend_stat);
//do_history_process(38743982, 100, 80);
/*
$rv = $redis_client->hSet('feeds:recommend:38743982:stat', 'startTime', 1556343401);
var_dump($rv);
$end = gettimeofday(true);
$rv = $redis_client->hSet('feeds:recommend:38743982:stat', 'endTime', (int)$end);
var_dump($rv);
//var_dump($rv);
//$result = $redis_client->HGetall('feeds:recommend:38743982:stat');
//var_dump($result);
$uid = 38743982;    
$stat = $redis_client->hmGet('feeds:recommend:'.$uid.':stat', array('readable', 'updatable', 'likeCount', 'likeIndex', 'hotCount', 'hotIndex'));
var_dump($stat);

$rv = call_user_func_array(array($redis_client, 'zadd'), array('test-1', 10, 'summer', 15, 'leon', 7, 'ian'));
var_dump($rv);
//var_dump($redis_client->zRange('test-1', 0, -1));
        
$rv = $redis_client->zRemRangeByRank('feeds:recommend:'.$uid.':like', 0, -1);
var_dump($rv);
*/
?>
