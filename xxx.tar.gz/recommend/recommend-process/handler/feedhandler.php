<?php
require_once('./lib/netclient_class.php');
global $g_redis_client;
function feedid_cmp_score($feedid_1, $feedid_2){
    return ($feedid_1['score'] < $feedid_2['score']) ? 1 : -1;
}

function feedid_cmp($feedid_1, $feedid_2){
    if ($feedid_1['timestamp'] == $feedid_2['timestamp']) {
        return 0;
    }

    return ($feedid_1['timestamp'] < $feedid_2['timestamp']) ? 1 : -1;
}

function _init_redis_connect(&$cli) {
    global $g_recommend_conf;
    global $g_redis_client;
    $cli = new Redis();
    $cli->connect($g_recommend_conf['backend']['redis_server']['ip'], $g_recommend_conf['backend']['redis_server']['port']);
    $cli->auth($g_recommend_conf['backend']['redis_server']['pwd']);
    if (empty($g_redis_client))
        $g_redis_client = $cli;
    return $cli;
}

function get_timestamp($uid, $type) {
    global $g_recommend_conf;
    global $g_redis_client;
    if (empty($g_redis_client))
        $g_redis_client = _init_redis_connect($g_redis_client);

    if ($type == 'start')    {
        $time = $g_redis_client->hGet('feeds:recommend:'.$uid.':stat', 'startTime');
    } else if ($type = 'end')    {
        $time = $g_redis_client->hGet('feeds:recommend:'.$uid.':stat', 'endTime');
    } else  {
        DEBUG && log::write('['.__LINE__.'] Can not get time server type:'.$type, 'debug');
        return NULL;
    }

    if ((empty($time)) || ($time === FALSE))
        return NULL;

    return (int)$time;
}

function set_timestamp($uid, $time, $type) {
    global $g_recommend_conf;
    global $g_redis_client;
    if (empty($g_redis_client))
        $g_redis_client = _init_redis_connect($g_redis_client);
    if ($type == 'start')    {
        $rv = $g_redis_client->hSet('feeds:recommend:'.$uid.':stat', 'startTime', (int)$time);
    } else if ($type = 'end')    {
        $rv = $g_redis_client->hSet('feeds:recommend:'.$uid.':stat', 'endTime', (int)$time);
    } else  {
        DEBUG && log::write('['.__LINE__.'] Can not get time server type:'.$type, 'debug');
        return NULL;
    }
}

function _according_to_user_verify($arr_uid) {
    global $g_recommend_conf;
    $arr_score = array();
//    DEBUG && log::write('['.__FILE__.']['.__LINE__.'] mysql:'.print_r($g_recommend_conf['db'], true), 'debug');
    $conn = mysqli_connect($g_recommend_conf['db']['host'], $g_recommend_conf['db']['user'],$g_recommend_conf['db']['pwd'],$g_recommend_conf['db']['database']); //建立数据库连接
    foreach ($arr_uid as $uid) {
        $sql = "SELECT * FROM user_verify where account=$uid";
//        DEBUG && log::write('['.__FILE__.']['.__LINE__.'] sql<'.$sql.'>', 'debug');
        $res = mysqli_query($conn, $sql);
        while ($row=mysqli_fetch_assoc($res)) {
            if ($row['hobby'] == 1)
                $arr_score[$uid] = $g_recommend_conf['point']['role']['hobby'];
            else if ($row['official'] == 1)
                $arr_score[$uid] = $g_recommend_conf['point']['role']['official'];
            else if ($row['person_identity'] == 1)
                $arr_score[$uid] = $g_recommend_conf['point']['role']['person_identity'];
            else
                $arr_score[$uid] = $g_recommend_conf['point']['role']['common'];
//            DEBUG && log::write('['.__FILE__.']['.__LINE__.'] sql<'.print_r($row, true).'>', 'debug');
        }
    }
    return $arr_score;
}

function _history_computering($arr_uid, $end_time, &$arr_feed) {
    global $g_recommend_conf;
    $timeline = $end_time - 3600 * 3;
    $arr_score = _according_to_user_verify($arr_uid);
//    DEBUG && log::write('['.__LINE__.'] feedidCnt<'.count($arr_feed).'> scoreCnt<'.count($arr_score).'> timeline<'.$timeline.'>', 'debug');
    foreach ($arr_feed as &$feed) {
        if (array_key_exists($feed['user_id'], $arr_score))
            $feed['score'] = $arr_score[$feed['user_id']];
        else
            $feed['score'] = $g_recommend_conf['point']['role']['common'];
//  DEBUG && log::write('['.__FILE__.']['.__LINE__.'] <'.$feed['user_id'].'> score<'.$feed['score'].'>', 'debug');
        if ($feed['timestamp'] > $timeline) {
            $feed['score'] += (int)(($feed['timestamp'] - $timeline ) / 36);
//            DEBUG && log::write('['.__FILE__.']['.__LINE__.'] time<'.$feed['timestamp'].'> score<'.$feed['score'].'>', 'debug');
        }
    }
}

function _get_history_feed($uid, $count, &$arr_feed) {
    global $g_recommend_conf;
    $arr_feed = array();

    $start_time = get_timestamp($uid, 'start');
    if ($start_time == NULL) {
//        DEBUG && log::write('['.__LINE__.'] Can not get start time', 'debug');
        $start_time = 0;
    }
    if (($end_time = get_timestamp($uid, 'end')) == NULL)  {
//        DEBUG && log::write('['.__LINE__.'] Can not get end time', 'debug');
        $end_time = 0;
    }
//    DEBUG && log::write('['.__LINE__.'] uid<'.$uid.'> start<'.$start_time.'> end<'.$end_time.'>', 'debug');
    if ($start_time != $end_time)
        $new_end_time = gettimeofday(true);//如果拉取时需要啦最新的和历史的feedid，保存当前时间戳，可以避免最新数组的排序

    if (get_update_mid($uid, $arr_uid) === FALSE)
        return FALSE;

    $arr_outbox_addr = explode(':', $g_recommend_conf['backend']['outbox_server']);
    $outbox_client = new netclient($arr_outbox_addr[0], $arr_outbox_addr[1]); 
    if ($outbox_client->open_conn(1) === FALSE) {
        log::write('['.__FILE__.']['.__LINE__.'] Connect server<'.$g_recommend['backend']['outbox_server'].'> failed', 'error');
        return FALSE;
    }

    $uid_count = count($arr_uid);
//    DEBUG && log::write('['.__FILE__.']['.__LINE__.'] update uid count<'.$uid_count.'>', 'debug');
    $arr_new = array();
    $arr_old = array();
    for ($i = 0; $i < $uid_count; $i += MAX_OUTBOX_REQUEST_COUNT) {
        $arr_slice_uid = array_slice($arr_uid, $i, MAX_OUTBOX_REQUEST_COUNT);

        $outbox_rqst_len = 4 + 2;
        $outbox_rqst_body = '';
        foreach ($arr_slice_uid as $_uid) {
            $outbox_rqst_body .= pack('L', $_uid);
            $outbox_rqst_len += 4;
        }

        $outbox_rqst = pack('LS', $outbox_rqst_len, OUTBOX_OPCODE) . $outbox_rqst_body;
        $outbox_resp = FALSE;
        if (($outbox_resp = $outbox_client->send_rqst($outbox_rqst, TIMEOUT)) === FALSE) {
            log::write('['.__FILE__.']['.__LINE__.'] Send failed', 'error');
            return FALSE;
        }

        $rv = unpack('Llen/Sresult', $outbox_resp);
        if ($rv['result'] != 0) {
            log::write('['.__FILE__.']['.__LINE__."] get_feedid: len: {$rv['len']} result: {$rv['result']}", 'error');
            return FALSE;
        }
//        DEBUG && log::write('['.__FILE__.']['.__LINE__.'] outbox result:'.print_r($rv, true), 'debug');

        $feedid_count = ($rv['len'] - OUTBOX_RESPONSE_HEAD_LEN) / FEEDID_LEN;
        for ($j = 0; $j != $feedid_count; ++$j) {
            $binary = substr($outbox_resp, OUTBOX_RESPONSE_HEAD_LEN + $j * FEEDID_LEN, FEEDID_LEN);
            $feedid = unpack("Luser_id/Scmd_id/Lapp_id/Ltimestamp", $binary);
//            DEBUG && log::write('['.__FILE__.']['.__LINE__.'] source feedid:'.print_r($feedid, true), 'debug');
            $tmp['user_id'] = $feedid['user_id'];
            $tmp['timestamp'] = $feedid['timestamp'];
            if ($start_time == $end_time) {//第一次做全量更新，全部放入最新列表中，然后取最新的count条
                $tmp['feedid'] = base64_encode($binary);
                $arr_new[] = $tmp;
//                    DEBUG && log::write('['.__FILE__.']['.__LINE__.'] first time new:'.print_r($tmp, true), 'debug');
            } else {
                if ($tmp['timestamp'] > $end_time) {
                    $tmp['feedid'] = base64_encode($binary);
//                    DEBUG && log::write('['.__FILE__.']['.__LINE__.'] new feedid:'.print_r($tmp, true), 'debug');
                    $arr_new[] = $tmp;
                } else if ($tmp['timestamp'] < $start_time) {
                    $tmp['feedid'] = base64_encode($binary);
                    $arr_old[] = $tmp;
//                    DEBUG && log::write('['.__FILE__.']['.__LINE__.'] old feedid:'.print_r($tmp, true), 'debug');
                }
            }
        }
    }

    if ($outbox_client->close_conn() === FALSE) {
        log::write('['.__FILE__.']['.__LINE__.'] Close failed', 'error');
        return FALSE;
    }

                    
    if (count($arr_new) > $count) {
//        DEBUG && log::write('['.__LINE__.'] new feedid count<'.count($arr_new).'>', 'debug');
        usort($arr_new, 'feedid_cmp');
        if ($start_time == $end_time) {
            $arr_feed = array_slice($arr_new, 0, $count); 
            set_timestamp($uid, $arr_feed[0]['timestamp'], 'end');
            $end_time = $arr_feed['0']['timestamp'];
//            DEBUG && log::write('['.__LINE__.'] new end time<'.$arr_feed[0]['timestamp'].'>', 'debug');
            set_timestamp($uid, $arr_feed[$count - 1]['timestamp'], 'start');
//            DEBUG && log::write('['.__LINE__.'] new start time<'.$arr_feed[$count - 1]['timestamp'].'>', 'debug');
        } else {
            $arr_feed = array_slice($arr_new, count($arr_new)-$count-1, $count);
            set_timestamp($uid, $arr_feed[0]['timestamp'], 'end');
            $end_time = $arr_feed['0']['timestamp'];
//            DEBUG && log::write('['.__FILE__.']['.__LINE__.'] new end time<'.$arr_feed[0]['timestamp'].'>', 'debug');
        }
    } else {
        usort($arr_old, 'feedid_cmp');
        $arr_old = array_slice($arr_old, 0, $count - count($arr_new));
//        DEBUG && log::write('['.__FILE__.']['.__LINE__.'] new feedid <'.count($arr_new).'> old nct <'.count($arr_old).'>', 'debug');
        set_timestamp($uid, $new_end_time, 'end');
        $end_time = $new_end_time;
//        DEBUG && log::write('['.__FILE__.']['.__LINE__.'] new end time<'.$new_end_time.'>', 'debug');
        set_timestamp($uid, $arr_old[count($arr_old) - 1]['timestamp'], 'start');
//        DEBUG && log::write('['.__FILE__.']['.__LINE__.'] new end time<'.$arr_old[count($arr_old) - 1]['timestamp'].'>', 'debug');
        $arr_feed = array_merge($arr_new, $arr_old);
    }
    _history_computering($arr_uid, $end_time, $arr_feed);
    return $arr_feed;
}
//获取最新更新文章的米米号集合，用于文章的检索
function get_update_mid($uid, &$arr_uid) { 
    global $g_recommend_conf;
    $arr_server_addr = explode(':', $g_recommend_conf['backend']['tag_server']);
    $redis_cli = new netclient($arr_server_addr[0], $arr_server_addr[1]);
    
    if ($redis_cli->open_conn(1) === FALSE){
        log::write('['.__FILE__.']['.__LINE__.'] Connect server<'.$g_recommend_conf['backend']['tag_server'].'> failed', 'error');
        return FALSE;
    }
    
    $timestamp = gettimeofday(true);
    $relation_rqst = pack("LLsLLLLL", 18+4+4+4, 10086, 0xA102, 0, $uid, 0, $timestamp, 300);
    $relation_resp = FALSE;
    
    if (($relation_resp = $redis_cli->send_rqst($relation_rqst,TIMEOUT)) === FALSE) {
        log::write('['.__FILE__.']['.__LINE__.'] Send server<'.$g_recommend['backend']['tag_server'].'> failed', 'error');
        return FALSE;
    }
    $rv = unpack('Llen/Lseq/scmd_id/Lcode/Lmimi', $relation_resp);
    if ($rv['code'] != 0) {
        log::write('['.__FILE__.']['.__LINE__.'] Server<'.$g_recommend['backend']['tag_server'].'> handle failed', 'error');
        return FALSE;
    }
    $relation_resp = substr($relation_resp, 18);
    $rv = unpack("Lunits", $relation_resp);
    $id_list = substr($relation_resp, 4);

//    empty($arr_uid[0]);
    for ($i = 0; $i < $rv['units']; ++$i) {
        $fan = unpack('Lid', $id_list);
        //array_push($arr_uid, $fan['id']);
        $arr_uid[] = $fan['id'];
        $id_list = substr($id_list, 4);
    }
    return TRUE;
}

function _push_history_feed($uid, $count, $index, $arr_feed) {
    $feed_cnt = count($arr_feed);
    if ($feed_cnt == 0) {
        log::write('['.__LINE__.']: user<'.$uid.'> total<'.$count.'> index<'.$index.'> No feed reset', 'error');
        $index = 0;
    } else if ($feed_cnt != $count) {
        $index = (int)($feed_cnt * $index / $count);
        DEBUG && log::write('['.__LINE__.']: user<'.$uid.'> total<'.$count.'> index<'.$index.'> have not enough feed', 'debug');
    }

    $arr_like = array();
    $arr_like[] = 'feeds:recommend:'.$uid.':like';
    $arr_hot = array();
    $arr_hot[] = 'feeds:recommend:'.$uid.':hot';
    for ($i = 0; $i != $index; ++$i) {
        $arr_like[] = $arr_feed[$i]['score'];
        $arr_like[] = $arr_feed[$i]['feedid'];
    }
//    DEBUG && log::write('['.__LINE__.']: like set '.print_r($arr_like, true), 'debug');
    for ($i = $index; $i != $feed_cnt; ++$i) {
        $arr_hot[] = $arr_feed[$i]['score'];
        $arr_hot[] = $arr_feed[$i]['feedid'];
    }
//    DEBUG && log::write('['.__LINE__.']: hot set '.print_r($arr_hot, true), 'debug');

    global $g_redis_client;
    if (empty($g_redis_client))
        $g_redis_client = _init_redis_connect($g_redis_client);
        
    $stat = $g_redis_client->hGetall('feeds:recommend:'.$uid.':stat');
//    DEBUG && log::write('['.__LINE__.']: recommend old stat'.print_r($stat, true), 'debug');
    if ($stat['readable'] === FALSE) {
        $stat['readable'] = 0;
        $stat['updatable'] = 1;
        $stat['likeCount'] = 0;
        $stat['likeIndex'] = 0;
        $stat['hotCount'] = 0;
        $stat['hotIndex'] = 0;
    }
    $rv = $g_redis_client->hSet('feeds:recommend:'.$uid.':stat', 'updatable', 2);

//    DEBUG && log::write('['.__LINE__.']: HSET feeds:recommend:'.$uid.':stat updatable 2 result<'.$rv.'>', 'debug');
    if ($stat['readable'] == 0) {
        $stat['likeCount'] = $index;
        $stat['hotCount'] = $feed_cnt - $index;
        $rv = $g_redis_client->zRemRangeByRank('feeds:recommend:'.$uid.':like', 0, -1);
//        DEBUG && log::write('['.__LINE__.']: ZREMRANGEBYRANK feeds:recommend:'.$uid.':like 0 -1 result<'.$rv.'>', 'debug');
        $rv = $g_redis_client->zRemRangeByRank('feeds:recommend:'.$uid.':hot', 0, -1);
//        DEBUG && log::write('['.__LINE__.']: ZREMRANGEBYRANK feeds:recommend:'.$uid.':hot 0 -1 result<'.$rv.'>', 'debug');
    } else {
        $rv = $g_redis_client->zRemRangeByRank('feeds:recommend:'.$uid.':like', $stat['likeIndex'] - $stat['likeCount'], -1);
//        DEBUG && log::write('['.__LINE__.']: ZREMRANGEBYRANK like <'.$rv.'>', 'debug');
        $rv = $g_redis_client->zRemRangeByRank('feeds:recommend:'.$uid.':hot', $stat['hotIndex'] - $stat['hotCount'], -1);
//        DEBUG && log::write('['.__LINE__.']: ZREMRANGEBYRANK hot <'.$rv.'>', 'debug');
        $stat['likeCount'] = $index + $stat['likeCount'] - $stat['likeIndex'];
        $stat['hotCount'] = $feed_cnt - $index + $stat['hotCount'] - $stat['hotIndex'];
    }
    $stat['readable'] = 1;
    $stat['updatable'] = 0;
    $stat['likeIndex'] = 0;
    $stat['hotIndex'] = 0;

    $rv = call_user_func_array(array($g_redis_client, 'zadd'), $arr_like);
//    DEBUG && log::write('['.__LINE__.']: ZADD like <'.$rv.'>', 'debug');
    $rv = call_user_func_array(array($g_redis_client, 'zadd'), $arr_hot);
//    DEBUG && log::write('['.__LINE__.']: ZADD like <'.$rv.'>', 'debug');

    DEBUG && log::write('['.__LINE__.']: recommend<'.$rv.'> new stat before'.print_r($stat, true), 'debug');
    $rv = $g_redis_client->hMset('feeds:recommend:'.$uid.':stat', $stat);

    $g_redis_client->hSet('feeds:recommend:'.$uid.':stat', 'readable', 1);
    $g_redis_client->hSet('feeds:recommend:'.$uid.':stat', 'updatable', 0);
    $g_redis_client->hSet('feeds:recommend:'.$uid.':stat', 'likeCount', $stat['likeCount']);
    $g_redis_client->hSet('feeds:recommend:'.$uid.':stat', 'likeIndex', $stat['likeIndex']);
    $g_redis_client->hSet('feeds:recommend:'.$uid.':stat', 'hotCount', $stat['hotCount']);
    $g_redis_client->hSet('feeds:recommend:'.$uid.':stat', 'hotIndex', $stat['hotIndex']);
    DEBUG && log::write('['.__LINE__.']: recommend<'.$rv.'> new stat end'.print_r($stat, true), 'debug');
    return;
}

function do_history_process($uid, $count, $index) {
    DEBUG && log::write('['.__LINE__.']: user<'.$uid.'> total<'.$count.'> index<'.$index.'>', 'debug');

    $arr_feed = _get_history_feed($uid, $count, $arr_feed);
    usort($arr_feed, 'feedid_cmp_score');
    
    //DEBUG && log::write('['.__FILE__.']['.__LINE__.'] result'.print_r($arr_feed, true), 'debug');
    _push_history_feed($uid, $count, $index, $arr_feed);
    return;
}

?>
